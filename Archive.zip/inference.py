# inference.py

import json
import pandas as pd
from eeg_preprocessing import normalize_data, segment_data, convert_to_tensor
from model_loader import get_model

def run_inference(raw_eeg_data: pd.DataFrame) -> str:
    """
    Preprocess the raw EEG data, run the inference, and return predictions.
    
    Parameters:
    - raw_eeg_data (pd.DataFrame): The raw EEG data.
    
    Returns:
    - str: The predicted text in JSON format.
    """
    model = get_model()
    
    # Preprocess the EEG data
    normalized_data = normalize_data(raw_eeg_data)
    segments = segment_data(normalized_data, 128, 64)
    eeg_tensor = convert_to_tensor(segments)
    
    # Perform inference
    with torch.no_grad():
        outputs = model(eeg_tensor)
    
    # Post-process outputs
    texts = [output for output in outputs]
    
    # Convert to JSON format
    results_json = json.dumps(texts)
    return results_json
